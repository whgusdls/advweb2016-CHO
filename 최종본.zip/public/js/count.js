(function($) {
  $(document).ready(function(){
    $(".example").TimeCircles( { time: {
      Seconds: { show : false},
      Minutes: { show : false}
    }}
   );

  });
})(jQuery);
